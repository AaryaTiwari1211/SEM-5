<?php
    $api_url = 'http://your-api-url/products.php?action=get_products';
    $products = json_decode(file_get_contents($api_url), true);
?>