<?php
    $products = [
        ['id' => 1, 'name' => 'Product 1', 'price' => 19.99],
        ['id' => 2, 'name' => 'Product 2', 'price' => 29.99],
        // Add more products as needed
    ];
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_products') {
        header('Content-Type: application/json');
        echo json_encode($products);
        exit;
    }
?>