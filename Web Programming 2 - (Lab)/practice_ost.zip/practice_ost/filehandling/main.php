<?php
    //Reading from a file
    $file = fopen("example.txt", "r");
    $content = fread($file, filesize("example.txt"));
    fclose($file);

    //Writing into a file
    $file = fopen("example.txt", "w");
    fwrite($file, "Hello, World!");
    fclose($file);

    //Appending into a file
    $file = fopen("example.txt", "a");
    fwrite($file, " Appended Text");
    fclose($file);

    //Checking if a file exists
    if (file_exists("example.txt")) {
        echo "File exists!";
    } else {
        echo "File does not exist.";
    }

    //Deleting a file
    unlink("example.txt");

    //Copying a file
    copy("source.txt", "destination.txt");
?>