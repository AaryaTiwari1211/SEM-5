<?php
include 'pdo.php';

if (isset($_POST['add_button'])) {
    $name = $_POST['add_name'];
    $age = $_POST['add_age'];

    $stmt = $conn->prepare("INSERT INTO names VALUES (:name, :age)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':age', $age);

    $stmt->execute();
    echo "Data added successfully!";
}

if (isset($_POST['remove_button'])) {
    $name = $_POST['remove_name'];
    $age = $_POST['remove_age'];

    $stmt = $conn->prepare("DELETE FROM names WHERE name = :name AND age = :age");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':age', $age);

    $stmt->execute();
    echo "Data deleted successfully!";
}

if (isset($_POST['update_button'])) {
    $originalName = $_POST['og_name'];
    $newName = $_POST['new_name'];
    $originalAge = $_POST['og_age'];
    $newAge = $_POST['new_age'];

    $stmt = $conn->prepare("UPDATE names SET name = :newName, age = :newAge WHERE name = :originalName AND age = :originalAge");
    $stmt->bindParam(':newName', $newName);
    $stmt->bindParam(':newAge', $newAge);
    $stmt->bindParam(':originalName', $originalName);
    $stmt->bindParam(':originalAge', $originalAge);
    $stmt->execute();
    echo "Data updated successfully!";
}

$conn = null;
?>