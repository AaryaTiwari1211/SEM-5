<?php

$nameRegex = '/^[A-Za-z\s]{3,}$/';
$emailRegex = '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
$phoneRegex = '/^[0-9]{10}$/';

function validateInput($input, $regex)
{
    return preg_match($regex, $input);
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = $_POST['text'];
    if (!validateInput($text, $nameRegex)) {
        $errors['text'] = 'Invalid name format. Please enter a valid name.';
    }
    $number = $_POST['number'];
    if (!validateInput($number, $phoneRegex)) {
        $errors['number'] = 'Invalid number format. Please enter a valid number.';
    }
    $checkbox = $_POST['checkbox'];
    $radio = $_POST['radio'];
    $textarea = $_POST['textarea'];
    $email = $_POST['email'];

    if (!validateInput($email, $emailRegex)) {
        $errors['email'] = 'Invalid email format. Please enter a valid email address.';
    }
    $password = $_POST['password'];
    $select = $_POST['select'];
    $file = $_FILES['file']['name'];
    $date = $_POST['date'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation Example</title>
    <style>
        .error {
            color: red;
        }
        form {
            display: flex;
            flex-direction: column;
            width: 30%;
            gap: 20px;
        }
    </style>
</head>

<body>
    <h2>Basic Form Validation</h2>
    <form method="post" enctype="multipart/form-data">
        <label for="text">Name:</label>
        <input type="text" id="text" name="text" required>

        <?php if (isset($errors['text']))
            echo '<p class="error">' . $errors['text'] . '</p>'; ?>

        <label for="number">Number:</label>
        <input type="number" id="number" name="number" required>
        
        <?php if (isset($errors['text']))
            echo '<p class="error">' . $errors['text'] . '</p>'; ?>

        <label for="checkbox">Checkbox:</label>
        <input type="checkbox" id="checkbox" name="checkbox">

        <label>Radio:</label>
        <input type="radio" id="radio1" name="radio" value="option1" required>

        <label for="radio1">Option 1</label>
        <input type="radio" id="radio2" name="radio" value="option2" required>

        <label for="radio2">Option 2</label>
        <label for="textarea">Textarea:</label>
        <textarea id="textarea" name="textarea" required></textarea>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <?php if (isset($errors['email']))
            echo '<p class="error">' . $errors['email'] . '</p>'; ?>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <label for="select">Select:</label>
        <select id="select" name="select" required>
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
        </select>

        <label for="file">File:</label>
        <input type="file" id="file" name="file" accept="image/*">

        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required>

        <br>
        <input type="submit" value="Submit">
    </form>
</body>

</html>